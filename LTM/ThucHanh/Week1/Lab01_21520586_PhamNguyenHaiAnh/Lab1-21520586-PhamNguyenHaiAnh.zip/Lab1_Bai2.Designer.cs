﻿
namespace BaiTap
{
    partial class Lab1_Bai2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exit_but = new System.Windows.Forms.Button();
            this.del_but = new System.Windows.Forms.Button();
            this.MinTextBox = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Label_2 = new System.Windows.Forms.Label();
            this.MinLabel = new System.Windows.Forms.Label();
            this.Label_1 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.Label_3 = new System.Windows.Forms.Label();
            this.MaxTextBox = new System.Windows.Forms.TextBox();
            this.MaxLabel = new System.Windows.Forms.Label();
            this.FindBut = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // exit_but
            // 
            this.exit_but.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit_but.Location = new System.Drawing.Point(463, 153);
            this.exit_but.Margin = new System.Windows.Forms.Padding(4);
            this.exit_but.Name = "exit_but";
            this.exit_but.Size = new System.Drawing.Size(120, 41);
            this.exit_but.TabIndex = 9;
            this.exit_but.Text = "Thoát";
            this.exit_but.UseVisualStyleBackColor = true;
            this.exit_but.Click += new System.EventHandler(this.exit_but_Click);
            // 
            // del_but
            // 
            this.del_but.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.del_but.Location = new System.Drawing.Point(298, 153);
            this.del_but.Margin = new System.Windows.Forms.Padding(4);
            this.del_but.Name = "del_but";
            this.del_but.Size = new System.Drawing.Size(117, 41);
            this.del_but.TabIndex = 8;
            this.del_but.Text = "Xóa";
            this.del_but.UseVisualStyleBackColor = true;
            this.del_but.Click += new System.EventHandler(this.del_but_Click);
            // 
            // MinTextBox
            // 
            this.MinTextBox.Location = new System.Drawing.Point(191, 302);
            this.MinTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.MinTextBox.Name = "MinTextBox";
            this.MinTextBox.Size = new System.Drawing.Size(132, 22);
            this.MinTextBox.TabIndex = 18;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(420, 100);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(71, 22);
            this.textBox2.TabIndex = 17;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(153, 97);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(82, 22);
            this.textBox1.TabIndex = 16;
            // 
            // Label_2
            // 
            this.Label_2.AutoSize = true;
            this.Label_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_2.Location = new System.Drawing.Point(311, 98);
            this.Label_2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_2.Name = "Label_2";
            this.Label_2.Size = new System.Drawing.Size(85, 25);
            this.Label_2.TabIndex = 15;
            this.Label_2.Text = "Số thứ 2";
            // 
            // MinLabel
            // 
            this.MinLabel.AutoSize = true;
            this.MinLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinLabel.Location = new System.Drawing.Point(57, 302);
            this.MinLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.MinLabel.Name = "MinLabel";
            this.MinLabel.Size = new System.Drawing.Size(118, 25);
            this.MinLabel.TabIndex = 14;
            this.MinLabel.Text = "Số nhỏ nhất";
            // 
            // Label_1
            // 
            this.Label_1.AutoSize = true;
            this.Label_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_1.Location = new System.Drawing.Point(60, 94);
            this.Label_1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_1.Name = "Label_1";
            this.Label_1.Size = new System.Drawing.Size(85, 25);
            this.Label_1.TabIndex = 13;
            this.Label_1.Text = "Số thứ 1";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(715, 98);
            this.textBox3.Margin = new System.Windows.Forms.Padding(4);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(72, 22);
            this.textBox3.TabIndex = 20;
            // 
            // Label_3
            // 
            this.Label_3.AutoSize = true;
            this.Label_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_3.Location = new System.Drawing.Point(607, 96);
            this.Label_3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_3.Name = "Label_3";
            this.Label_3.Size = new System.Drawing.Size(85, 25);
            this.Label_3.TabIndex = 19;
            this.Label_3.Text = "Số thứ 3";
            // 
            // MaxTextBox
            // 
            this.MaxTextBox.Location = new System.Drawing.Point(507, 298);
            this.MaxTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.MaxTextBox.Name = "MaxTextBox";
            this.MaxTextBox.Size = new System.Drawing.Size(132, 22);
            this.MaxTextBox.TabIndex = 22;
            // 
            // MaxLabel
            // 
            this.MaxLabel.AutoSize = true;
            this.MaxLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaxLabel.Location = new System.Drawing.Point(373, 298);
            this.MaxLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.MaxLabel.Name = "MaxLabel";
            this.MaxLabel.Size = new System.Drawing.Size(111, 25);
            this.MaxLabel.TabIndex = 21;
            this.MaxLabel.Text = "Số lớn nhất";
            // 
            // FindBut
            // 
            this.FindBut.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FindBut.Location = new System.Drawing.Point(133, 153);
            this.FindBut.Margin = new System.Windows.Forms.Padding(4);
            this.FindBut.Name = "FindBut";
            this.FindBut.Size = new System.Drawing.Size(117, 41);
            this.FindBut.TabIndex = 23;
            this.FindBut.Text = "Tìm";
            this.FindBut.UseVisualStyleBackColor = true;
            this.FindBut.Click += new System.EventHandler(this.FindBut_Click);
            // 
            // Lab1_Bai2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.FindBut);
            this.Controls.Add(this.MaxTextBox);
            this.Controls.Add(this.MaxLabel);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.Label_3);
            this.Controls.Add(this.MinTextBox);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Label_2);
            this.Controls.Add(this.MinLabel);
            this.Controls.Add(this.Label_1);
            this.Controls.Add(this.exit_but);
            this.Controls.Add(this.del_but);
            this.Name = "Lab1_Bai2";
            this.Text = "Bai Tap 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button exit_but;
        private System.Windows.Forms.Button del_but;
        private System.Windows.Forms.TextBox MinTextBox;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label Label_2;
        private System.Windows.Forms.Label MinLabel;
        private System.Windows.Forms.Label Label_1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label Label_3;
        private System.Windows.Forms.TextBox MaxTextBox;
        private System.Windows.Forms.Label MaxLabel;
        private System.Windows.Forms.Button FindBut;
    }
}