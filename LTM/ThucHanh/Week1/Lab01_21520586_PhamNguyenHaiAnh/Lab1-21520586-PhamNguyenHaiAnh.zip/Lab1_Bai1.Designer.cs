﻿
namespace BaiTap
{
    partial class Lab1_Bai1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.plus_but = new System.Windows.Forms.Button();
            this.Label_1 = new System.Windows.Forms.Label();
            this.div_but = new System.Windows.Forms.Button();
            this.sub_but = new System.Windows.Forms.Button();
            this.mul_but = new System.Windows.Forms.Button();
            this.del_but = new System.Windows.Forms.Button();
            this.exit_but = new System.Windows.Forms.Button();
            this.resultLabel = new System.Windows.Forms.Label();
            this.Label_2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.resultBox = new System.Windows.Forms.TextBox();
            this.Tittle = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // plus_but
            // 
            this.plus_but.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.plus_but.Location = new System.Drawing.Point(55, 354);
            this.plus_but.Margin = new System.Windows.Forms.Padding(4);
            this.plus_but.Name = "plus_but";
            this.plus_but.Size = new System.Drawing.Size(41, 41);
            this.plus_but.TabIndex = 0;
            this.plus_but.Text = "+";
            this.plus_but.UseVisualStyleBackColor = true;
            this.plus_but.Click += new System.EventHandler(this.plus_but_Click);
            // 
            // Label_1
            // 
            this.Label_1.AutoSize = true;
            this.Label_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_1.Location = new System.Drawing.Point(63, 116);
            this.Label_1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_1.Name = "Label_1";
            this.Label_1.Size = new System.Drawing.Size(85, 25);
            this.Label_1.TabIndex = 2;
            this.Label_1.Text = "Số thứ 1";
            this.Label_1.Click += new System.EventHandler(this.Label_1_Click);
            // 
            // div_but
            // 
            this.div_but.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.div_but.Location = new System.Drawing.Point(291, 354);
            this.div_but.Margin = new System.Windows.Forms.Padding(4);
            this.div_but.Name = "div_but";
            this.div_but.Size = new System.Drawing.Size(40, 41);
            this.div_but.TabIndex = 3;
            this.div_but.Text = "/";
            this.div_but.UseVisualStyleBackColor = true;
            this.div_but.Click += new System.EventHandler(this.div_but_Click);
            // 
            // sub_but
            // 
            this.sub_but.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sub_but.Location = new System.Drawing.Point(133, 354);
            this.sub_but.Margin = new System.Windows.Forms.Padding(4);
            this.sub_but.Name = "sub_but";
            this.sub_but.Size = new System.Drawing.Size(39, 41);
            this.sub_but.TabIndex = 4;
            this.sub_but.Text = "-";
            this.sub_but.UseVisualStyleBackColor = true;
            this.sub_but.Click += new System.EventHandler(this.sub_but_Click);
            // 
            // mul_but
            // 
            this.mul_but.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mul_but.Location = new System.Drawing.Point(211, 354);
            this.mul_but.Margin = new System.Windows.Forms.Padding(4);
            this.mul_but.Name = "mul_but";
            this.mul_but.Size = new System.Drawing.Size(40, 41);
            this.mul_but.TabIndex = 5;
            this.mul_but.Text = "x";
            this.mul_but.UseVisualStyleBackColor = true;
            this.mul_but.Click += new System.EventHandler(this.mul_but_Click);
            // 
            // del_but
            // 
            this.del_but.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.del_but.Location = new System.Drawing.Point(55, 417);
            this.del_but.Margin = new System.Windows.Forms.Padding(4);
            this.del_but.Name = "del_but";
            this.del_but.Size = new System.Drawing.Size(117, 41);
            this.del_but.TabIndex = 6;
            this.del_but.Text = "Xóa";
            this.del_but.UseVisualStyleBackColor = true;
            this.del_but.Click += new System.EventHandler(this.del_but_Click);
            // 
            // exit_but
            // 
            this.exit_but.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit_but.Location = new System.Drawing.Point(211, 417);
            this.exit_but.Margin = new System.Windows.Forms.Padding(4);
            this.exit_but.Name = "exit_but";
            this.exit_but.Size = new System.Drawing.Size(120, 41);
            this.exit_but.TabIndex = 7;
            this.exit_but.Text = "Thoát";
            this.exit_but.UseVisualStyleBackColor = true;
            this.exit_but.Click += new System.EventHandler(this.exit_but_Click);
            // 
            // resultLabel
            // 
            this.resultLabel.AutoSize = true;
            this.resultLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resultLabel.Location = new System.Drawing.Point(63, 282);
            this.resultLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.resultLabel.Name = "resultLabel";
            this.resultLabel.Size = new System.Drawing.Size(80, 25);
            this.resultLabel.TabIndex = 8;
            this.resultLabel.Text = "Kết quả";
            // 
            // Label_2
            // 
            this.Label_2.AutoSize = true;
            this.Label_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_2.Location = new System.Drawing.Point(63, 198);
            this.Label_2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_2.Name = "Label_2";
            this.Label_2.Size = new System.Drawing.Size(85, 25);
            this.Label_2.TabIndex = 9;
            this.Label_2.Text = "Số thứ 2";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(197, 118);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(132, 22);
            this.textBox1.TabIndex = 10;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(197, 198);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(132, 22);
            this.textBox2.TabIndex = 11;
            // 
            // resultBox
            // 
            this.resultBox.Location = new System.Drawing.Point(197, 285);
            this.resultBox.Margin = new System.Windows.Forms.Padding(4);
            this.resultBox.Name = "resultBox";
            this.resultBox.Size = new System.Drawing.Size(191, 22);
            this.resultBox.TabIndex = 12;
            // 
            // Tittle
            // 
            this.Tittle.AutoSize = true;
            this.Tittle.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tittle.Location = new System.Drawing.Point(117, 39);
            this.Tittle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Tittle.Name = "Tittle";
            this.Tittle.Size = new System.Drawing.Size(159, 39);
            this.Tittle.TabIndex = 13;
            this.Tittle.Text = "Tính toán";
            // 
            // Lab1_Bai1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(405, 503);
            this.Controls.Add(this.Tittle);
            this.Controls.Add(this.resultBox);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Label_2);
            this.Controls.Add(this.resultLabel);
            this.Controls.Add(this.exit_but);
            this.Controls.Add(this.del_but);
            this.Controls.Add(this.mul_but);
            this.Controls.Add(this.sub_but);
            this.Controls.Add(this.div_but);
            this.Controls.Add(this.Label_1);
            this.Controls.Add(this.plus_but);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Lab1_Bai1";
            this.Text = "Bai Tap 1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button plus_but;
        private System.Windows.Forms.Label Label_1;
        private System.Windows.Forms.Button div_but;
        private System.Windows.Forms.Button sub_but;
        private System.Windows.Forms.Button mul_but;
        private System.Windows.Forms.Button del_but;
        private System.Windows.Forms.Button exit_but;
        private System.Windows.Forms.Label resultLabel;
        private System.Windows.Forms.Label Label_2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox resultBox;
        private System.Windows.Forms.Label Tittle;
    }
}