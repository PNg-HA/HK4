﻿
namespace BaiTap
{
    partial class BaiTap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Task1Button = new System.Windows.Forms.Button();
            this.Task2Button = new System.Windows.Forms.Button();
            this.Task3Button = new System.Windows.Forms.Button();
            this.Task4Button = new System.Windows.Forms.Button();
            this.Task5Button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Task1Button
            // 
            this.Task1Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Task1Button.Location = new System.Drawing.Point(104, 94);
            this.Task1Button.Margin = new System.Windows.Forms.Padding(4);
            this.Task1Button.Name = "Task1Button";
            this.Task1Button.Size = new System.Drawing.Size(100, 36);
            this.Task1Button.TabIndex = 0;
            this.Task1Button.Text = "BaiTap1";
            this.Task1Button.UseVisualStyleBackColor = true;
            this.Task1Button.Click += new System.EventHandler(this.Task1Button_Click);
            // 
            // Task2Button
            // 
            this.Task2Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Task2Button.Location = new System.Drawing.Point(391, 94);
            this.Task2Button.Margin = new System.Windows.Forms.Padding(4);
            this.Task2Button.Name = "Task2Button";
            this.Task2Button.Size = new System.Drawing.Size(100, 36);
            this.Task2Button.TabIndex = 1;
            this.Task2Button.Text = "BaiTap2";
            this.Task2Button.UseVisualStyleBackColor = true;
            this.Task2Button.Click += new System.EventHandler(this.Task2Button_Click);
            // 
            // Task3Button
            // 
            this.Task3Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Task3Button.Location = new System.Drawing.Point(104, 189);
            this.Task3Button.Margin = new System.Windows.Forms.Padding(4);
            this.Task3Button.Name = "Task3Button";
            this.Task3Button.Size = new System.Drawing.Size(100, 36);
            this.Task3Button.TabIndex = 2;
            this.Task3Button.Text = "BaiTap3";
            this.Task3Button.UseVisualStyleBackColor = true;
            this.Task3Button.Click += new System.EventHandler(this.Task3Button_Click);
            // 
            // Task4Button
            // 
            this.Task4Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Task4Button.Location = new System.Drawing.Point(391, 189);
            this.Task4Button.Margin = new System.Windows.Forms.Padding(4);
            this.Task4Button.Name = "Task4Button";
            this.Task4Button.Size = new System.Drawing.Size(100, 36);
            this.Task4Button.TabIndex = 3;
            this.Task4Button.Text = "BaiTap4";
            this.Task4Button.UseVisualStyleBackColor = true;
            this.Task4Button.Click += new System.EventHandler(this.Task4Button_Click);
            // 
            // Task5Button
            // 
            this.Task5Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Task5Button.Location = new System.Drawing.Point(104, 284);
            this.Task5Button.Margin = new System.Windows.Forms.Padding(4);
            this.Task5Button.Name = "Task5Button";
            this.Task5Button.Size = new System.Drawing.Size(100, 36);
            this.Task5Button.TabIndex = 4;
            this.Task5Button.Text = "BaiTap5";
            this.Task5Button.UseVisualStyleBackColor = true;
            this.Task5Button.Click += new System.EventHandler(this.Task5Button_Click);
            // 
            // BaiTap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(609, 424);
            this.Controls.Add(this.Task5Button);
            this.Controls.Add(this.Task4Button);
            this.Controls.Add(this.Task3Button);
            this.Controls.Add(this.Task2Button);
            this.Controls.Add(this.Task1Button);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "BaiTap";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Task1Button;
        private System.Windows.Forms.Button Task2Button;
        private System.Windows.Forms.Button Task3Button;
        private System.Windows.Forms.Button Task4Button;
        private System.Windows.Forms.Button Task5Button;
    }
}

