DROP TRIGGER "main"."update_MailBox_after_insert_mail";
DROP TRIGGER "main"."update_MailBox_default_attribute_with_name";
DROP TRIGGER "main"."update_MailBox_firstunseen_after_update_mail_seen_flag";
DROP TRIGGER "main"."update_MailBox_recent_after_update_mail_recent_flag";
DROP TRIGGER update_MailBox_after_delete_mail;