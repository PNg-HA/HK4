﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MailServer.Imap
{
    internal class UserInfo
    {
        public string name { get; set; }
        public string password { get; set; }
    }
}